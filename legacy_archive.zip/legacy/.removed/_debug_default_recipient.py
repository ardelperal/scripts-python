import os
from common.config import Config
print('ENV DEFAULT_RECIPIENT=', os.getenv('DEFAULT_RECIPIENT'))
print('Config.default_recipient=', Config().default_recipient)
